// Some custom math functions
#ifndef MYMATH_H
#define MYMATH_H

#define MYMATH_PI 3.14159

int mymath_times_two(int n);
int mymath_square(int n);
char* mymath_even_odd_message(int n);

#endif
