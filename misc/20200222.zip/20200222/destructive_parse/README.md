tl;dr  use static for file scope globals.  preferably static const

Computer Speed

contiguous sequential memory access is fast

contiguous memory accessed densely packed

densely packed

sequential access for cache prefetching (or at least predictable access pattern)

[](https://www.notion.so/c7b1d72514c84f0ba1f3bf194b663268#fb3accb1266d4f7e8022333662597f0f)

-Wall  all warnings

[https://en.wikipedia.org/wiki/Global_variable#C_and_C++](https://en.wikipedia.org/wiki/Global_variable#C_and_C++)

[https://stackoverflow.com/questions/14027317/what-is-the-difference-between-file-scope-and-program-scope](https://stackoverflow.com/questions/14027317/what-is-the-difference-between-file-scope-and-program-scope)

shift+alt+down  copy line down in vscode