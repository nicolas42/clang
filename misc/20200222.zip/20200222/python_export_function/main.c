
int test(int a)
{
	return 2*a;
}
