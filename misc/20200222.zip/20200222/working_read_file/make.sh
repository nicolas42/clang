gcc -c -Wall -pedantic *.c
gcc -Wall -pedantic *.o
rm *.o
./a.out